describe('Testing Controller', function(){
	beforeEach(angular.mock.module('Assignment'));

    var $controller, $scope, controller;;
	
    beforeEach(inject(function(_$controller_){
    $controller = _$controller_;
    }));
	 
	beforeEach(function() {
      $scope = {};
      controller = $controller('PolishController', { $scope: $scope });
    });
	
	it('should return postfix evaluation 5 if the input expression is 2 3 +', function() {
      $scope.expression = '2 3 +';
      $scope.result = $scope.polishNotation($scope.expression);
      expect($scope.result).toEqual(5);
    });
	it('should return postfix evaluation 8 if the input expression is 2 3 ^', function() {
      $scope.expression = '2 3 ^';
      $scope.result = $scope.polishNotation($scope.expression);
      expect($scope.result).toEqual(8);
    });
	it('should return postfix evaluation 11 if the input expression is 2 3 + 4 4 * -', function() {
      $scope.expression = '2 3 + 4 4 * -';
      $scope.result = $scope.polishNotation($scope.expression);
      expect($scope.result).toEqual(11);
    });
	it('should return postfix evaluation 1 if the input expression is 3 4 -', function() {
      $scope.expression = '3 4 -';
      $scope.result = $scope.polishNotation($scope.expression);
      expect($scope.result).toEqual(1);
    });
	it('should return postfix evaluation 12 if the input expression is 3 4 *', function() {
      $scope.expression = '3 4 *';
      $scope.result = $scope.polishNotation($scope.expression);
      expect($scope.result).toEqual(12);
    });
});