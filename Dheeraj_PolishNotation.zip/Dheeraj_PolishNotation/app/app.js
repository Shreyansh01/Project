var app = angular.module('Assignment', []);

app.controller('PolishController', function($scope) {
	$scope.polishNotation = function(expression){
		var resultArray = [];
		var polishExp = expression.split(" ");
		for(var i=0;i<polishExp.length;i++){
			if(!isNaN(polishExp[i])){
				resultArray.push(polishExp[i]);				
			}
			else{
				var a = resultArray.pop();
				var b = resultArray.pop();
				if(polishExp[i] === "+"){
					resultArray.push(parseInt(a) + parseInt(b));
				} else if(polishExp[i] === "-"){
					resultArray.push(parseInt(a) - parseInt(b));
				} else if(polishExp[i] === "*"){
					resultArray.push(parseInt(a) * parseInt(b));
				} else if(polishExp[i] === "/"){
					resultArray.push(parseInt(a) / parseInt(b));
				} else if(polishExp[i] === "^"){
					resultArray.push(Math.pow(parseInt(b), parseInt(a)));
				}
			}			
		}
		if(resultArray.length > 1) {
			alert("Invalid entry");
		} else {							
			$scope.output=resultArray.pop();
			return $scope.output;
		}		
	}
});
